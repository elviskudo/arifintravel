<?php

$email_to = "youremailaddress@yourdomain.com"; // your email address
$email_subject = "Contact Form Message"; // email subject line
$thankyou = "thankyou.htm"; // thank you page

// if you update the question on the form -
// you need to update the questions answer below
$antispam_answer = "25";

?>