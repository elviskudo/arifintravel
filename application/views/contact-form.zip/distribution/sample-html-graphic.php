<?php session_start(); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>

<title>Contact Form - Sample</title>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
<meta name="description" content="">
<meta name="keywords"    content="">
<link rel="stylesheet" type="text/css" href="contact-form/style-basic.css">
<link rel="stylesheet" type="text/css" href="contact-form/style-graphic.css">

</head>
<body>

<?php

$contact_form_fields = array(
  array('name'    => 'Name:',
        'type'    => 'name',
        'require' => 1),
  array('name'    => 'E-mail:',
        'type'    => 'email',
        'require' => 1),
  array('name'    => 'Tel/fax:',
        'type'    => 'input',
        'require' => 1),
  array('name'    => 'Subject:',
        'type'    => 'subject',
        'require' => 1),
  array('name'    => 'Message:',
        'type'    => 'textarea',
        'require' => 1),
  array('name'    => 'Turing number:',
        'type'    => 'turing',
        'require' => 1,
        'url'     => 'contact-form/image.php',
        'prompt'  => 'Enter the number displayed above'));

$contact_form_graph           = true;
$contact_form_xhtml           = false;

$contact_form_email           = "me@some-domain.com";
$contact_form_encoding        = "utf-8";
$contact_form_default_subject = "Default subject";
$contact_form_message_prefix  = "Sent from contact form\r\n==============================\r\n\r\n";

include_once "contact-form/contact-form.php";

?>

</body>
</html>