<?php session_start(); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>

<title>Contact Form - Sample</title>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<meta name="description" content="" />
<meta name="keywords"    content="" />
<link rel="stylesheet" type="text/css" href="contact-form/style-basic.css" />
<link rel="stylesheet" type="text/css" href="contact-form/style-simple.css" />

</head>
<body>

<?php

$contact_form_fields = array(
  array('name'    => 'Department:',
        'type'    => 'department',
        'require' => 1,
        'default' => '-',
        'items'   => array('sale@some-domain.com' => 'Sales',
                           'tech@some-domain.com' => 'Technical support')),
  array('name'    => 'Name:',
        'type'    => 'name',
        'require' => 1),
  array('name'    => 'E-mail:',
        'type'    => 'email',
        'require' => 1),
  array('name'    => 'Tel/fax:',
        'type'    => 'input',
        'require' => 1),
  array('name'    => 'Country:',
        'type'    => 'select',
        'require' => 1,
        'default' => '-',
        'items'   => array('Germany',
                           'United Kingdom',
                           'USA')),
  array('name'    => 'Subject:',
        'type'    => 'subject',
        'require' => 1),
  array('name'    => 'Message:',
        'type'    => 'textarea',
        'require' => 1),
  array('name'    => 'Attachment:',
        'type'    => 'upload',
        'require' => 0,
        'maxsize' => 128*1024),
  array('name'    => 'Turing number:',
        'type'    => 'turing',
        'require' => 1,
        'url'     => 'contact-form/image.php',
        'prompt'  => 'Enter the number displayed above'),
  array('name'    => '',
        'type'    => 'checkbox',
        'require' => 1,
        'prompt'  => 'I confirm that I have read FAQ before submitting question'));

$contact_form_graph           = false;
$contact_form_xhtml           = true;

$contact_form_email           = "me@some-domain.com";
$contact_form_encoding        = "utf-8";
$contact_form_default_subject = "Default subject";
$contact_form_message_prefix  = "Sent from contact form\r\n==============================\r\n\r\n";

include_once "contact-form/contact-form.php";

?>

</body>
</html>