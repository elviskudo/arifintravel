Features:

1. Field types:

     type=department - this fields allows to select target e-mail address
     type=email      - sender's e-mail
     type=name       - sender's name
     type=subject    - subject
     type=turing     - turing number

     type=checkbox   - input:checkbox
     type=input      - input:text
     type=upload     - input:upload
     type=select     - select
     type=textarea   - textarea

   Check sample scripts to see how to use different field types.

Testing the script:

1. Open one of the sample forms (sample-***-***.php) in text editor.
2. Replace "***@some-domain.com" with your e-mail address.
3. Upload files to your server.
4. Open selected sample form in your browser.

Installation:

1. Add the following code in the beginning of your contact page:
     <?php session_start(); ?>

2. Add the following code in the head section (if necessary, correct URL):
     <link rel="stylesheet" type="text/css" href="contact-form/style-simple.css">
   or
     <link rel="stylesheet" type="text/css" href="contact-form/style-graphic.css">

3. Add the following code to your contact page (if necessary, correct include path):
     <?php
     $contact_form_fields         = array(...);

     $contact_form_graph          = true_or_false;
     $contact_form_xhtml          = true_or_false;

     $contact_form_email          = "me@some-domain.com";
     $contact_form_encoding       = "utf-8";
     $contact_form_message_prefix = "Sent from contact form\r\n==============================\r\n\r\n";

     include "contact-form/contact-form.php";
     ?>

   $contact_form_fields          - field list
   $contact_form_graph           - true to use graphic button, false to use text button
   $contact_form_xhtml           - true to use   xhtml format, false to use html format
   $contact_form_email           - your e-mail address
   $contact_form_encoding        - e-mail encoding
   $contact_form_default_subject - default e-mail subject
   $contact_form_message_prefix  - e-mail prefix

4. You can prepopulate field using query string.


If you have any difficulties installing the script, feel free to contact me.

If you find this script useful, consider placing the link to the homepage of this script
http://www.php-development.ru/php-scripts/contact-form.php
somewhere on your site.

Ilya S. Lyubinskiy
http://www.php-development.ru/